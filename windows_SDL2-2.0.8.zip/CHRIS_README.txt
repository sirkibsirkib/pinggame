read this
https://github.com/ggez/ggez/blob/master/docs/BuildingForEveryPlatform.md